 <footer role="contentinfo" class="bottom">
     <div>
         <div class="section">
             <div class="new"></div>
         </div>
         <div class="iparys_inherited">
             <div class="iparsys parsys">
                 <div class="referenceComponent reference parbase section">
                     <div class="cq-dd-paragraph">
                         <div class="footernavigationcomp footerNavigationComponent parbase">
                             <div class="page-footer">
                                 <div class="container">
                                     <div class="page-footer_content">
                                         <div class="page-footer_legal">
                                             <p>© Copyright 2023 Travsify Global Inc.¦ &nbsp;<a href="/company/legal/intellectual/" adhocenable="false">All
                                                     rights reserved</a>. | 635 Pine Ave, Pacific Grove, California,
                                                 U.S.A. |  +12134686786 </p>
                                         </div>
                                         <nav class="page-footer_links mobile-display">
                                             <ul class="page-footer_links_list">
                                                 <li class="page-footer_links_item">
                                                     <a class="page-footer_link " href="https://www.salesforce.com/company/legal/">
                                                         Legal
                                                     </a>
                                                 </li>
                                                 <li class="page-footer_links_item">
                                                     <a class="page-footer_link " href="/company/legal/sfdc-website-terms-of-service/">
                                                         Terms of Service
                                                     </a>
                                                 </li>
                                                 <li class="page-footer_links_item">
                                                     <a class="page-footer_link " href="/company/privacy/">
                                                         Privacy Information
                                                     </a>
                                                 </li>
                                                 <li class="page-footer_links_item">
                                                     <a class="page-footer_link " href="https://www.salesforce.com/company/disclosure/">
                                                         Responsible Disclosure
                                                     </a>
                                                 </li>
                                                 <li class="page-footer_links_item">
                                                     <a class="page-footer_link " href="https://trust.salesforce.com/en/" target="_blank">
                                                         Trust
                                                     </a>
                                                 </li>
                                                 <li class="page-footer_links_item">
                                                     <a class="page-footer_link " href="https://www.salesforce.com/company/contact-us/?d=cta-glob-footer-11">
                                                         Contact
                                                     </a>
                                                 </li>
                                                 <li class="page-footer_links_item">
                                                     <a class="page-footer_link optanon-toggle-display" href="#" data-ignore-geolocation="true">
                                                         Cookie Preferences
                                                     </a>
                                                 </li>
                                                 <li class="page-footer_links_item">
                                                     <a class="page-footer_link " href="/form/other/privacy-request/?d=cta-footer-1">
                                                         <img alt="" class="footer-link-icon footer-link-icon_left" src="../assets2/images/icon-cpra.svg">Your Privacy
                                                         Choices
                                                     </a>
                                                 </li>
                                             </ul>
                                         </nav>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="referenceComponent reference parbase section">
                     <div class="cq-dd-paragraph">
                         <div class="dockedcontainer dockedContainer parbase">
                             <div class="docked-container  margin-20-right-lg fixed">
                                 <div class="fixedFooterCTAItemComponent parbase section">
                                 </div>
                                 <div class="fixedFooterCTAItemComponent parbase section">
                                 </div>
                                 <div class="randomImageComponent list parbase section">
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </footer>

 <div class="sf-call">
     <div class="call-btn-wrapper">
         <a class="btn" href="tel:0800 020 0431" aria-label="Contact, Telefoonnummer"></a>
     </div>
 </div>

 <script type="text/javascript">
     window.document.dispatchEvent(
         new CustomEvent('www_track', {
             detail: {
                 event: 'custEv_pageDataAvailable',
                 templateName: '',
                 templateId: '',
                 taxonomy: JSON.parse('{"pageTagsManual":[],"pageTagsAuto":[]}'),
                 experiment: {
                     'optimizelyExp': '',
                     'optimizelyVar': ''
                 }
             },
         })
     );
     //});
 </script>
 <script defer="" src="assets2/js/chat.js"></script>
 <script defer="" src="assets2/js/tableau-2.9.2.min.js"></script>
 </body>

 </html>